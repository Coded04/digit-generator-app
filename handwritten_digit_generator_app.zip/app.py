
import streamlit as st
import torch
import torchvision.transforms as transforms
import matplotlib.pyplot as plt
import numpy as np

st.title("🧠 Handwritten Digit Generator")

# Load generator model (dummy model for placeholder)
@st.cache_resource
def load_model():
    # Replace this with torch.load for your actual model
    class DummyGenerator(torch.nn.Module):
        def forward(self, z, label=None):
            return torch.rand(1, 1, 28, 28)
    return DummyGenerator()

model = load_model()

digit = st.slider("Choose digit (0-9)", 0, 9, 0)
generate = st.button("Generate")

if generate:
    z = torch.randn(1, 100)
    with torch.no_grad():
        generated = model(z)
    img = generated.squeeze().numpy()

    # Plot image
    st.image(img, caption=f"Generated Digit: {digit}", width=200)
