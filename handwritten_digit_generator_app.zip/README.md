
# Handwritten Digit Generator Web App

This Streamlit app generates synthetic handwritten digits using a pretrained generator model (e.g., GAN trained on MNIST).

## How to Use
1. Upload the code to a public GitHub repository.
2. Go to https://share.streamlit.io/
3. Select "Deploy a public app from GitHub"
4. Point to `app.py` as the entry point.
